package com.example.laundryfinderapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ProofAdapter extends RecyclerView.Adapter<ProofAdapter.VH> {

    private final Context context;
    private final ArrayList<ProofModel> list;

    public ProofAdapter(Context context, ArrayList<ProofModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_proof, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        ProofModel p = list.get(position);

        h.txtType.setText(p.type == null ? "" : p.type);
        h.txtNote.setText(p.note == null || p.note.isEmpty() ? "(No note)" : p.note);

        String dateStr = "";
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
            dateStr = sdf.format(new Date(p.createdAt));
        } catch (Exception ignored) {}
        h.txtDate.setText(dateStr);

        Glide.with(context).load(p.imageUrl).into(h.imgThumb);

        h.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, ProofViewActivity.class);
            i.putExtra("imageUrl", p.imageUrl);
            i.putExtra("type", p.type);
            i.putExtra("note", p.note);
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        ImageView imgThumb;
        TextView txtType, txtNote, txtDate;

        public VH(@NonNull View itemView) {
            super(itemView);
            imgThumb = itemView.findViewById(R.id.imgThumb);
            txtType = itemView.findViewById(R.id.txtType);
            txtNote = itemView.findViewById(R.id.txtNote);
            txtDate = itemView.findViewById(R.id.txtDate);
        }
    }
}


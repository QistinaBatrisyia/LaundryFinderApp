package com.example.laundryfinderapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.UUID;

public class ReceiptProofActivity extends AppCompatActivity {

    private ImageView imgPreview;
    private ProgressBar progressBar;
    private EditText edtNote;

    private RadioGroup rgPurpose;
    private RadioButton rbReceipt, rbLaundry, rbIssue, rbNone;

    private Button btnPickImage, btnUpload, btnMyProofs;

    private Uri selectedImageUri;  // final chosen image (camera or gallery)
    private Uri cameraTempUri;     // temp uri for camera output

    private FirebaseAuth mAuth;
    private StorageReference storageRef;
    private DatabaseReference dbRef;

    private boolean attachMode = false;

    // Permission launcher
    private final ActivityResultLauncher<String> requestCameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    openChooserCameraGallery();
                } else {
                    Toast.makeText(this, "Camera permission denied.", Toast.LENGTH_LONG).show();
                }
            });

    // Gallery picker launcher
    private final ActivityResultLauncher<String> pickFromGalleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    selectedImageUri = uri;
                    imgPreview.setImageURI(uri);
                }
            });

    // Camera launcher (saves to our temp Uri)
    private final ActivityResultLauncher<Uri> takePictureLauncher =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), success -> {
                if (success && cameraTempUri != null) {
                    selectedImageUri = cameraTempUri;
                    imgPreview.setImageURI(selectedImageUri);
                } else {
                    Toast.makeText(this, "Camera cancelled.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt_proof);

        imgPreview = findViewById(R.id.imgPreview);
        progressBar = findViewById(R.id.progressBar);
        edtNote = findViewById(R.id.edtNote);

        rgPurpose = findViewById(R.id.rgPurpose);
        rbReceipt = findViewById(R.id.rbReceipt);
        rbLaundry = findViewById(R.id.rbLaundry);
        rbIssue = findViewById(R.id.rbIssue);

        btnPickImage = findViewById(R.id.btnPickImage);
        btnUpload = findViewById(R.id.btnUpload);
        btnMyProofs = findViewById(R.id.btnMyProofs);

        mAuth = FirebaseAuth.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference();
        dbRef = FirebaseDatabase.getInstance().getReference();

        attachMode = getIntent().getBooleanExtra("attachMode", false);

        btnPickImage.setOnClickListener(v -> {
            // Request camera permission first (so camera option always works)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA);
            } else {
                openChooserCameraGallery();
            }
        });

        btnMyProofs.setOnClickListener(v ->
                startActivity(new Intent(ReceiptProofActivity.this, ProofListActivity.class))
        );

        btnUpload.setOnClickListener(v -> uploadProof());
    }

    private void openChooserCameraGallery() {
        // Simple chooser dialog
        String[] options = {"Camera", "Gallery"};
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Select Image")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        openCamera();
                    } else {
                        openGallery();
                    }
                })
                .show();
    }

    private void openGallery() {
        pickFromGalleryLauncher.launch("image/*");
    }

    private void openCamera() {
        try {
            cameraTempUri = createTempImageUri();
            takePictureLauncher.launch(cameraTempUri);
        } catch (IOException e) {
            Toast.makeText(this, "Camera error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private Uri createTempImageUri() throws IOException {
        File tempFile = File.createTempFile("proof_", ".jpg", getCacheDir());
        return FileProvider.getUriForFile(
                this,
                getPackageName() + ".fileprovider",
                tempFile
        );
    }

    private String getSelectedType() {
        if (rbLaundry.isChecked()) return "LAUNDRY_PROOF";
        if (rbIssue.isChecked()) return "ISSUE_PROOF";
        if (rbReceipt.isChecked()) return "RECEIPT";
        return "NONE";
    }

    private void uploadProof() {
        if (mAuth.getCurrentUser() == null) {
            Toast.makeText(this, "Not logged in.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedImageUri == null) {
            Toast.makeText(this, "Please select an image first.", Toast.LENGTH_SHORT).show();
            return;
        }

        final String typeFinal = getSelectedType();
        if ("NONE".equals(typeFinal)) {
            Toast.makeText(this, "Please choose a purpose.", Toast.LENGTH_SHORT).show();
            return;
        }

        final String uid = mAuth.getCurrentUser().getUid();
        final String proofId = UUID.randomUUID().toString();
        final String noteFinal = edtNote.getText().toString().trim();
        final long createdAtFinal = System.currentTimeMillis();
        final Uri imageUriFinal = selectedImageUri;

        progressBar.setVisibility(View.VISIBLE);
        btnUpload.setEnabled(false);

        final StorageReference fileRef = storageRef.child("proofs/" + uid + "/" + proofId + ".jpg");

        fileRef.putFile(imageUriFinal)
                .addOnSuccessListener(taskSnapshot ->
                        fileRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {

                            final String imageUrl = downloadUri.toString();

                            HashMap<String, Object> proofMap = new HashMap<>();
                            proofMap.put("proofId", proofId);
                            proofMap.put("imageUrl", imageUrl);
                            proofMap.put("type", typeFinal);
                            proofMap.put("note", noteFinal);
                            proofMap.put("createdAt", createdAtFinal);

                            dbRef.child("proofs").child(uid).child(proofId)
                                    .setValue(proofMap)
                                    .addOnSuccessListener(unused -> {
                                        progressBar.setVisibility(View.GONE);
                                        btnUpload.setEnabled(true);

                                        Toast.makeText(this, "Uploaded successfully ✅", Toast.LENGTH_SHORT).show();

                                        if ("ISSUE_PROOF".equals(typeFinal)) {
                                            Intent i = new Intent(this, IssueReportActivity.class);
                                            i.putExtra("proofId", proofId);
                                            i.putExtra("imageUrl", imageUrl);
                                            startActivity(i);
                                            finish();
                                            return;
                                        }

                                        if (attachMode) {
                                            Intent result = new Intent();
                                            result.putExtra("proofId", proofId);
                                            result.putExtra("proofUrl", imageUrl);
                                            result.putExtra("proofType", typeFinal);
                                            setResult(RESULT_OK, result);
                                            finish();
                                            return;
                                        }

                                        startActivity(new Intent(this, ProofListActivity.class));
                                        finish();
                                    })
                                    .addOnFailureListener(e -> {
                                        progressBar.setVisibility(View.GONE);
                                        btnUpload.setEnabled(true);
                                        Toast.makeText(this, "DB save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                    });

                        })
                ).addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    btnUpload.setEnabled(true);
                    Toast.makeText(this, "Upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }
}

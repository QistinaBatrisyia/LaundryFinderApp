package com.example.laundryfinderapp;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class ProofViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proof_view);

        TextView txtBack = findViewById(R.id.txtBack);
        TextView txtInfo = findViewById(R.id.txtInfo);
        ImageView imgFull = findViewById(R.id.imgFull);

        txtBack.setOnClickListener(v -> finish());

        String imageUrl = getIntent().getStringExtra("imageUrl");
        String type = getIntent().getStringExtra("type");
        String note = getIntent().getStringExtra("note");

        txtInfo.setText("Type: " + (type == null ? "" : type) + "\nNote: " + (note == null ? "" : note));

        Glide.with(this).load(imageUrl).into(imgFull);
    }
}
